=== Orichi Social Media Buttons ===
Contributors: Orichi
Tags: best Wordpress plugin, Social Media, Buttons, follow me, Social sharing, Social , Social media
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a brief description of the plugin. This description should be no more than 150 characters. No markup here.

== Description ==

Embed the customised Orichi Social Media Buttons, like – facebook, twitter, youtube, instagram, telegram, tiktok, whatsapp to your Website. 

Add Simple Social Buttons to your website and multiply your business with these Social Sharing buttons.
This is the best Wordpress plugin as it can be customised and placed to the: Left or right side of the page and with customisable top margins.
Try to make the best though Social Sharing Buttons, likefacebook, twitter, youtube, instagram, telegram, tiktok, whatsapp. and display your content to millions with Simple Social Buttons. 

The big beautiful social media sharing buttons can now be disabled from viewing on the mobile responsive website, by barely a tick. For users not interested in viewing the Social Buttons, now has an option to tick a checkbox which disables the buttons to be viewed on mobile devices.

== Installation ==

1. Upload the plugin folder `Orichi Social Media Buttons` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the "Plugins -> Installed plugins -> Activate Orichi  Social Media Buttons" menu in WordPress.
3. Find Orichi Social Media Buttons Plugin in -> Settings options.

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets directory or the directory that contains the stable readme.txt (tags or trunk) must be named screenshot-1.(png|jpg|jpeg|gif).

== Changelog ==

= 1.0 =
* Initial release.

== License ==
This plugin is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this plugin; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.