

<div class="wrap">
    <h2 class="title"><img src="<?php echo esc_url($plugin_url) ?>/images/icon-pl.png" />Social Media Buttons</h2>
    <div id="poststuff">

        <div id="post-body" class="metabox-holder columns-2">

            <!-- main content -->
            <div id="post-body-content">

                <div class="meta-box-sortables ui-sortable">

                    <?php if (!isset($pos_lr) || $pos_lr == ''): ?>

                        <div class="postbox box-left">
                            <div class="inside">
                                <form name="alsocial_form" method="post" action="">							
                                    <input type="hidden" name="alsocial_form_submitted" value="Y">
                                    <div class="image-social">
                                        <h3>Show/Hide Plugin</h3>
                                        <p>Select one of those button show/hide</p>
                                        <div class="item-name ed">
                                            <div class="switch-field">
                                                <input type="radio" id="radio-one" name="pos_on" value="yes" <?php checked($pos_on, yes); ?>/>
                                                <label for="radio-one">Enable Plugins</label>
                                                <input type="radio" id="radio-two" name="pos_on" value="no" <?php checked($pos_on, no); ?> />
                                                <label for="radio-two">Disable Plugins</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="image-social">
                                        <h3>Button Setting</h3>
                                        <p>Select one of those button styles</p>
                                        <div class="tabs">
                                            <ul id="tabs-nav">
                                                <li><a href="#tab1"><img src="<?php echo esc_url($plugin_url) ?>/images/whatsapp-fill-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab2"><img src="<?php echo esc_url($plugin_url) ?>/images/telegram-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab3"><img src="<?php echo esc_url($plugin_url) ?>/images/youtube-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab4"><img src="<?php echo esc_url($plugin_url) ?>/images/instagram-1-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab5"><img src="<?php echo esc_url($plugin_url) ?>/images/tiktok-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab6"><img src="<?php echo esc_url($plugin_url) ?>/images/facebook-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab7"><img src="<?php echo esc_url($plugin_url) ?>/images/twitter.png" /></a></li>
                                            </ul> <!-- END tabs-nav -->
                                            <div id="tabs-content">
                                                <div id="tab1" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_whatsapp" placeholder="Enter your whatsapp link..."  id="alsocial_whatsapp" type="text" value="<?php echo esc_attr($alsocial_whatsapp) ?>" class="regular-text" />
                                                </div>
                                                <div id="tab2" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_telegram" placeholder="Enter your telegram link..." id="alsocial_telegram" type="text" value="<?php echo esc_attr($alsocial_telegram); ?>" class="regular-text" /> 
                                                </div>
                                                <div id="tab3" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_youtube" placeholder="Enter your youtube link..."  id="alsocial_youtube" type="text" value="<?php echo esc_attr($alsocial_youtube); ?>" class="regular-text" /> 
                                                </div>
                                                <div id="tab4" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_instagram" placeholder="Enter your instagram link..." id="alsocial_instagram" type="text" value="<?php echo esc_attr($alsocial_instagram); ?>" class="regular-text" />
                                                </div>
                                                <div id="tab5" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_tiktok" placeholder="Enter your tiktok link..." id="alsocial_tiktok" type="text" value="<?php echo esc_attr($alsocial_tiktok); ?>" class="regular-text" />
                                                </div>
                                                <div id="tab6" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_facebook" placeholder="Enter your facebook link..." id="alsocial_facebook" type="text" value="<?php echo esc_attr($alsocial_facebook); ?>" class="regular-text" /> 
                                                </div>
                                                <div id="tab7" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_twitter" placeholder="Enter your twitter link..." id="alsocial_twitter" type="text" value="<?php echo esc_attr($alsocial_twitter); ?>" class="regular-text" />  
                                                </div>
                                            </div> <!-- END tabs-content -->
                                        </div> <!-- END tabs -->
                                    </div>
                                    <div class="image-social setting-social-button">
                                        <h3>Social Media Setting Style</h3>
                                        <p>Select one of those button styles</p>
                                        <div class="item-name">
                                            <label>Buttons Position Left / Right</label>
                                            <div class="selector">
                                                <select name="pos_lr_1"> 
                                                    <option value="right" <?php selected($pos_lr, right); ?>>Right </option>
                                                    <option value="left" <?php selected($pos_lr, left); ?>>Left </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="item-name">
                                            <label>Buttons Position Top / Bottom</label>
                                            <div class="selector">
                                                <select name="pos_tb"> 
                                                    <option value="t" <?php selected($pos_tb, t); ?>>Top </option>
                                                    <option value="b" <?php selected($pos_tb, b); ?>>Bottom </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <input class="button-primary" type="submit" name="alsocial_facebook_submit" value="Save Settings" />
                                </form>

                            </div> <!-- .inside -->

                        </div> <!-- .postbox -->

                    <?php else: ?>



                    <?php endif; ?>
                    <?php if (isset($pos_lr) && $pos_lr != ''): ?>

                        <div class="postbox box-left">
                            <div class="inside">
                                <form name="alsocial_form" method="post" action="">							
                                    <input type="hidden" name="alsocial_form_submitted" value="Y">
                                    <div class="image-social">
                                        <h3>Show/Hide Plugin</h3>
                                        <p>Select one of those button show/hide</p>
                                        <div class="item-name ed">
                                            <div class="switch-field">
                                                <input type="radio" id="radio-one" name="pos_on" value="yes" <?php checked($pos_on, yes); ?>/>
                                                <label for="radio-one">Enable Plugins</label>
                                                <input type="radio" id="radio-two" name="pos_on" value="no" <?php checked($pos_on, no); ?> />
                                                <label for="radio-two">Disable Plugins</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="image-social">
                                        <h3>Button Setting</h3>
                                        <p>Select one of those button styles</p>
                                        <div class="tabs">
                                            <ul id="tabs-nav">
                                                <li><a href="#tab1"><img src="<?php echo esc_url($plugin_url) ?>/images/whatsapp-fill-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab2"><img src="<?php echo esc_url($plugin_url) ?>/images/telegram-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab3"><img src="<?php echo esc_url($plugin_url) ?>/images/youtube-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab4"><img src="<?php echo esc_url($plugin_url) ?>/images/instagram-1-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab5"><img src="<?php echo esc_url($plugin_url) ?>/images/tiktok-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab6"><img src="<?php echo esc_url($plugin_url) ?>/images/facebook-svgrepo-com.png" /></a></li>
                                                <li><a href="#tab7"><img src="<?php echo esc_url($plugin_url) ?>/images/twitter.png" /></a></li>
                                            </ul> <!-- END tabs-nav -->
                                            <div id="tabs-content">
                                                <div id="tab1" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_whatsapp" placeholder="Enter your whatsapp link..."  id="alsocial_whatsapp" type="text" value="<?php echo esc_attr($alsocial_whatsapp); ?>" class="regular-text" />
                                                </div>
                                                <div id="tab2" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_telegram" placeholder="Enter your telegram link..." id="alsocial_telegram" type="text" value="<?php echo esc_attr($alsocial_telegram); ?>" class="regular-text" /> 
                                                </div>
                                                <div id="tab3" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_youtube" placeholder="Enter your youtube link..."  id="alsocial_youtube" type="text" value="<?php echo esc_attr($alsocial_youtube); ?>" class="regular-text" /> 
                                                </div>
                                                <div id="tab4" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_instagram" placeholder="Enter your instagram link..." id="alsocial_instagram" type="text" value="<?php echo esc_attr($alsocial_instagram); ?>" class="regular-text" />
                                                </div>
                                                <div id="tab5" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_tiktok" placeholder="Enter your tiktok link..." id="alsocial_tiktok" type="text" value="<?php echo esc_attr($alsocial_tiktok); ?>" class="regular-text" />
                                                </div>
                                                <div id="tab6" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_facebook" placeholder="Enter your facebook link..." id="alsocial_facebook" type="text" value="<?php echo esc_attr($alsocial_facebook); ?>" class="regular-text" /> 
                                                </div>
                                                <div id="tab7" class="tab-content">
                                                    <h4>Link</h4>
                                                    <input name="alsocial_twitter" placeholder="Enter your twitter link..." id="alsocial_twitter" type="text" value="<?php echo esc_attr($alsocial_twitter); ?>" class="regular-text" />  
                                                </div>
                                            </div> <!-- END tabs-content -->
                                        </div> <!-- END tabs -->
                                    </div>
                                    <div class="image-social setting-social-button">
                                        <h3>Social Media Setting Style</h3>
                                        <p>Select one of those button styles</p>
                                        <div class="item-name">
                                            <label>Buttons Position Left / Right</label>
                                            <div class="selector">
                                                <select name="pos_lr_1"> 
                                                    <option value="right" <?php selected($pos_lr, right); ?>>Right </option>
                                                    <option value="left" <?php selected($pos_lr, left); ?>>Left </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="item-name">
                                            <label>Buttons Position Top / Bottom</label>
                                            <div class="selector">
                                                <select name="pos_tb"> 
                                                    <option value="t" <?php selected($pos_tb, t); ?>>Top </option>
                                                    <option value="b" <?php selected($pos_tb, b); ?>>Bottom </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <input class="button-primary" type="submit" name="alsocial_facebook_submit" value="Save Settings" />
                                </form>

                            </div> <!-- .inside -->

                        </div> <!-- .postbox -->
                    <?php endif; ?>
                </div> <!-- .meta-box-sortables .ui-sortable -->

            </div> <!-- post-body-content -->

            <!-- sidebar -->
            <div id="postbox-container-1" class="postbox-container">

                <div class="meta-box-sortables">

                    <div class="postbox">

                        <h3><span>About Company</span></h3>
                        <div class="inside">
                            <a href="https://orichi.info/" target="_blank"><img src="<?php echo esc_url($plugin_url) ?>/images/logo-team.jpeg" style="width:120px"></a>
                            <p>Indian IT Outsourcing Company thành Viet Nam IT Company </p>
                        </div> <!-- .inside -->

                    </div> <!-- .postbox -->

                </div> <!-- .meta-box-sortables -->

            </div> <!-- #postbox-container-1 .postbox-container -->

        </div> <!-- #post-body .metabox-holder .columns-2 -->

        <br class="clear">
    </div> <!-- #poststuff -->

</div> <!-- .wrap -->