<?php
$options = get_option('alsocial_badges');
$alsocial_facebook = $options['alsocial_facebook'];
$alsocial_whatsapp = $options['alsocial_whatsapp'];
$alsocial_youtube = $options['alsocial_youtube'];
$alsocial_twitter = $options['alsocial_twitter'];
$alsocial_telegram = $options['alsocial_telegram'];
$alsocial_tiktok = $options['alsocial_tiktok'];
$alsocial_instagram = $options['alsocial_instagram'];
$pos_lr = $options['pos_lr'];
$pos_tb = $options['pos_tb'];
$pos_on = $options['pos_on'];
$top_px = $options['top_px'];
$effect_bt = $options['effect_bt'];
$hide_mobile = $options['mobile'];
$plugin_url = WP_PLUGIN_URL . '/al-social-media-buttons';
?>
<!--[if IE]>
<style>
   .social-icon {
    background-color: #33353B;
    background-image: url('<?php echo esc_url($plugin_url); ?>/images/social-icons.png'); 
}

</style>
<![endif]-->

<?php
if ($pos_on == 'no'):
    ?>
    <style>
        .social-icons {
            display: none !important;
        }
    </style> 
<?php endif; ?>
<?php
if ($hide_mobile == 1):
    ?> 
    <style>
        @media (max-width:640px){
            .social-icon {
                display: none;
            }
        }
    </style>  
<?php endif; ?>
<?php
if ($pos_lr == 'left'):
    ?>
    <style>
        .social-icons {
            left: 0;
        }
    </style> 
<?php endif; ?>
<?php
if ($pos_tb == 'b'):
    ?>
    <style>
        .social-icons {
            top: inherit;
            bottom:  0;
        }
    </style> 
<?php endif; ?>
<div class="social-icons" style="top:<?php echo esc_url( $top_px) ?>px;">
    <?php if ($alsocial_facebook): ?>
        <a class="socialitems" target="_blank" href="<?php echo esc_url($alsocial_facebook); ?>" id="facebook-btn">
            <img src="<?php echo esc_url($plugin_url) ?>/images/facebook-svgrepo-com.png" alt=""/>
        </a>
    <?php endif; ?>
    <?php if ($alsocial_whatsapp): ?>
        <a class="socialitems" target="_blank" href="<?php echo esc_url($alsocial_whatsapp); ?>" id="whatsapp-btn">
            <img src="<?php echo esc_url($plugin_url) ?>/images/whatsapp-fill-svgrepo-com.png" alt=""/>
        </a>
    <?php endif; ?>
    <?php if ($alsocial_twitter): ?>
        <a class="socialitems" target="_blank" href="<?php echo esc_url($alsocial_twitter); ?>" id="twitter-btn">
            <img src="<?php echo esc_url($plugin_url) ?>/images/twitter.png" alt=""/>
        </a>
    <?php endif; ?>
    <?php if ($alsocial_youtube): ?>
        <a class="socialitems" target="_blank" href="<?php echo esc_url($alsocial_youtube); ?>" id="youtube-btn">
            <img src="<?php echo esc_url($plugin_url) ?>/images/youtube-svgrepo-com.png" alt=""/>
        </a>
    <?php endif; ?>
    <?php if ($alsocial_telegram): ?>
        <a class="socialitems" target="_blank" href="<?php echo esc_url($alsocial_telegram); ?>" id="telegram-btn">
            <img src="<?php echo esc_url($plugin_url) ?>/images/telegram-svgrepo-com.png" alt=""/>
        </a>
    <?php endif; ?>
    <?php if ($alsocial_tiktok): ?>
        <a class="socialitems" target="_blank" href="<?php echo esc_url($alsocial_tiktok); ?>" id="tiktok-btn">
            <img src="<?php echo esc_url($plugin_url) ?>/images/tiktok-svgrepo-com.png" alt=""/>
        </a>
    <?php endif; ?>
    <?php if ($alsocial_instagram): ?>
        <a class="socialitems" target="_blank" href="<?php echo esc_url($alsocial_instagram); ?>" id="instagram-btn">
            <img src="<?php echo esc_url($plugin_url) ?>/images/instagram-1-svgrepo-com.png" alt=""/>
        </a>
    <?php endif; ?>
</div>
