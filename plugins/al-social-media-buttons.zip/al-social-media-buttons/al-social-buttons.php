<?php

/**
 * Plugin Name: Orichi Social Media Buttons
 * Plugin URI: https://orichi.info/
 * Description: Orichi Social Media Buttons plugin adds social media buttons to your site.
 * Version: 2.0.5
 * Author: Orichi
 * Author URI:
 */
$plugin_url = WP_PLUGIN_URL . '/al-social-media-buttons';
$options = array();

/*
 * 	Add a link to our plugin in the admin menu
 * 	under 'Settings >Orichi Social Buttons'
 *
 */

function alsocial_badges_menu() {

    /*
     * 	Use the add_options_page function
     * 	add_options_page( $page_title, $menu_title, $capability, $menu-slug, $function ) 
     *
     */
    add_options_page(
            'Orichi Social Buttons Settings', 'Orichi Social Buttons Settings', 'manage_options', 'alsocial-badges', 'alsocial_badges_options_page'
    );
}

add_action('admin_menu', 'alsocial_badges_menu');

function alsocial_badges_options_page() {

    if (!current_user_can('manage_options')) {

        wp_die('You do not have sufficient permissions to access this page.');
    }

    global $plugin_url;
    global $options;

    if (isset($_POST['alsocial_form_submitted'])) {

        $hidden_field = esc_html($_POST['alsocial_form_submitted']);

        if ($hidden_field == 'Y') {

            $alsocial_facebook = esc_html($_POST['alsocial_facebook']);
            $alsocial_whatsapp = esc_html($_POST['alsocial_whatsapp']);
            $alsocial_youtube = esc_html($_POST['alsocial_youtube']);
            $alsocial_telegram = esc_html($_POST['alsocial_telegram']);
            $alsocial_twitter = esc_html($_POST['alsocial_twitter']);
            $alsocial_tiktok = esc_html($_POST['alsocial_tiktok']);
            $alsocial_instagram = esc_html($_POST['alsocial_instagram']);
            $pos_lr = esc_html($_POST['pos_lr_1']);
            $pos_tb = esc_html($_POST['pos_tb']);
            $pos_on = esc_html($_POST['pos_on']);
            $options['alsocial_facebook'] = $alsocial_facebook;
            $options['alsocial_whatsapp'] = $alsocial_whatsapp;
            $options['alsocial_youtube'] = $alsocial_youtube;
            $options['alsocial_twitter'] = $alsocial_twitter;
            $options['alsocial_tiktok'] = $alsocial_tiktok;
            $options['alsocial_telegram'] = $alsocial_telegram;
            $options['alsocial_instagram'] = $alsocial_instagram;
            $options['mobile'] = $mobile;
            $options['pos_lr'] = $pos_lr;
            $options['pos_tb'] = $pos_tb;
            $options['pos_on'] = $pos_on;
            $options['last_updated'] = time();

            update_option('alsocial_badges', $options);
        }
    }

    $options = get_option('alsocial_badges');

    if ($options != '') {

        $alsocial_facebook = $options['alsocial_facebook'];
        $alsocial_whatsapp = $options['alsocial_whatsapp'];
        $alsocial_twitter = $options['alsocial_twitter'];
        $alsocial_telegram = $options['alsocial_telegram'];
        $alsocial_tiktok = $options['alsocial_tiktok'];
        $alsocial_youtube = $options['alsocial_youtube'];
        $alsocial_instagram = $options['alsocial_instagram'];
        $pos_lr = $options['pos_lr'];
        $pos_tb = $options['pos_tb'];
        $pos_on = $options['pos_on'];
    }

    require( 'inc/options-page-wrapper.php' );
}

/* Load Style-sheet for plugin */

function alsocial_badges_backend_styles() {

    wp_enqueue_style('alsocial_badges_backend_css', plugins_url('al-social-media-buttons/alsocial-badges.css'));
     wp_enqueue_style('general', plugins_url('al-social-media-buttons/inc/css/general.css'));
    wp_enqueue_script('alsocial', plugins_url('al-social-media-buttons/inc/js/alsocial.js'), array('jquery'), '', false);
}

add_action('admin_head', 'alsocial_badges_backend_styles');

/* Load Javascript for plugin */

function alsocial_badges_frontend_scripts_and_styles() {

    wp_enqueue_style('alsocial_badges_frontend_css', plugins_url('al-social-media-buttons/alsocial-badges.css'));
    wp_enqueue_style('general', plugins_url('al-social-media-buttons/inc/css/general.css'));
}

add_action('wp_enqueue_scripts', 'alsocial_badges_frontend_scripts_and_styles');

/* Load Front End */

function front_end_load() {
    require( 'inc/front-end.php' );
}

add_action('wp_head', 'front_end_load');
?>
